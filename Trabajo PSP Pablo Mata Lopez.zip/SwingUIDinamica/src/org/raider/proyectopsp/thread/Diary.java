package org.raider.proyectopsp.thread;

import org.raider.proyectopsp.controller.ControllerMainFrame;
import org.raider.proyectopsp.util.Values;

import java.io.File;
import java.io.IOException;

/**
 * Created by raider on 27/11/15.
 */
public class Diary extends Thread{

    private ControllerMainFrame cmf;
    private boolean pause = false;

    public Diary (ControllerMainFrame cmf) {
        this.cmf = cmf;
    }

    @Override
    public void run() {

        while (isAlive()) {

            while (!cmf.getDiaryFrame().panel1.isVisible()) {

                if (isPaused()) {
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    pause = false;
                }
                cmf.getDlm().removeAllElements();
                if (new File(Values.diaryPATH).exists()) {
                    for (String a : cmf.cargarDiario()) {
                        cmf.getDlm().addElement(a);
                    }
                }
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    public void pause(boolean p) { pause = p; }

    public boolean isPaused() {return pause;}
}
