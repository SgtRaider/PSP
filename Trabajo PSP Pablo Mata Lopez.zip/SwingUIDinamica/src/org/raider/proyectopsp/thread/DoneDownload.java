package org.raider.proyectopsp.thread;

import org.raider.proyectopsp.controller.ControllerMainFrame;

import java.io.IOException;

/**
 * Created by raider on 25/11/15.
 */
public class DoneDownload extends Thread{

    private ControllerMainFrame cmf;
    private Boolean op = false;

    public DoneDownload (ControllerMainFrame cmf) {
        this.cmf = cmf;
    }

    @Override
    public void run() {

        while (isAlive()) {

            for (int i = 0; i < cmf.getDownloadInProcess().size(); i++) {

                op = false;
                if (cmf.getDownloadInProcess().get(i).isFinished()) {
                    if (cmf.getDownloadInProcess().size() < 1 || cmf.getDownloadInProcessName().size() < 1) {
                        op = true;
                        break;
                    }
                    try {
                        cmf.añadirEntradaDiario("Descarga Terminada", cmf.getDownloadInProcessName().get(i));
                        cmf.getDownloadInProcess().remove(cmf.getDownloadInProcess().get(i));
                        cmf.getDownloadInProcessName().remove(cmf.getDownloadInProcessName().get(i));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (op = true)break;
            }

            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
