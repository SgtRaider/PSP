package org.raider.proyectopsp.controller;

import org.raider.proyectopsp.thread.Diary;
import org.raider.proyectopsp.thread.DoneDownload;
import org.raider.proyectopsp.util.Values;
import org.raider.proyectopsp.view.*;
import raider.Download.HTTP;
import raider.Util.Utilities;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

/**
 * Created by raider on 15/11/15.
 */
public class ControllerMainFrame implements ActionListener {

    private MainFrame m;
    private DiaryFrame diaryFrame;
    private AñadirLayout al;
    private AñadirVariosLayout avl;
    private DownloadFrame df;
    private ArrayList<DownloadFrame> downloadFrameList;
    private List<HTTP> downloadList;
    private List<String> urlList;
    private List<String> diaryList;
    private List<HTTP> downloadInProcess;
    private List<String> downloadInProcessName;
    private DefaultListModel<String> dlm;
    private Diary d;

    public ControllerMainFrame(MainFrame m) {



        if (new File(System.getProperty("user.home") + File.separator + "Descargas").exists()) {

            Values.descargaPATH = System.getProperty("user.home") + File.separator + "Descargas";

        } else {

            if (new File(System.getProperty("user.home") + File.separator + "Downloads").exists()) {

                Values.descargaPATH = System.getProperty("user.home") + File.separator + "Downloads";
            }
        }

        if (new File(System.getProperty("user.home") + File.separator + "Documentos").exists()) {

            Values.diaryPATH = System.getProperty("user.home") + File.separator + "Documentos" + File.separator + "diario.txt";

        } else {

            if (new File(System.getProperty("user.home") + File.separator + "Documents").exists()) {

                Values.diaryPATH = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "diario.txt";
            }
        }



        this.m = m;
        m.lbRuta.setText(Values.descargaPATH);
        downloadFrameList = new ArrayList<>();
        downloadList = new ArrayList<>();
        urlList = new ArrayList<>();
        downloadInProcess = new ArrayList<>();
        downloadInProcessName = new ArrayList<>();
        dlm = new DefaultListModel<>();
        diaryList = new ArrayList<>();


        DiaryFrame diaryFrame = new DiaryFrame();
        this.diaryFrame = diaryFrame;
        diaryFrame.jlDiario.setModel(dlm);

        m.jpDiario.add(diaryFrame.panel1);
        diaryFrame.panel1.setVisible(false);
        m.jpDiario.repaint();


        m.btDiario.addActionListener(this);
        m.btAñadir.addActionListener(this);
        m.btSeleccion.addActionListener(this);
        m.btParar.addActionListener(this);
        m.btEliminar.addActionListener(this);
        m.btReiniciar.addActionListener(this);
        m.btCambiarRuta.addActionListener(this);


        iniciarCb();

        DoneDownload dd = new DoneDownload(this);
        dd.start();
        d = new Diary(this);
        d.start();

        try {
            Properties configuracion = new Properties();
            configuracion.load(new FileInputStream("Descargas.props"));
            Values.descargaPATH = configuracion.getProperty("path");
        } catch (FileNotFoundException e) {
            try {
                añadirEntradaDiario("Properties no encontradas", "Descargas.props");
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public void iniciarCb() {

        m.cbAñadir.addItem("Una URL");
        m.cbAñadir.addItem("Varias URL");
        m.cbAñadir.addItem("Url Documento");

        m.cbEliminar.addItem("Datos Descargados y Descarga");
        m.cbEliminar.addItem("Solo Descarga");
    }

    public void parar(Object s) {

        if (s == m.btParar) {

            for (int i = 0; i < downloadFrameList.size(); i++) {

                if (downloadFrameList.get(i).cbSeleccion.isSelected()) {
                    if (!downloadFrameList.get(i).lbPorcentaje.getText().equals("100%")) {
                        if (!downloadFrameList.get(i).lbPorcentaje.getText().equals("0%")) {
                            downloadList.get(i).cancel(true);
                            downloadFrameList.get(i).lbPorcentaje.setText("0%");
                            downloadFrameList.get(i).pbDescarga.setValue(0);
                            downloadFrameList.get(i).lbNdescarga.setText(downloadFrameList.get(i).lbNdescarga.getText() + " (Cancelada)");
                            try {
                                añadirEntradaDiario("Descarga Cancelada", fileName(urlList.get(i)));
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        } else {

            for (int i = 0; i < downloadFrameList.size(); i++) {

                if (downloadFrameList.get(i).btParar == s) {
                    if (!downloadFrameList.get(i).lbPorcentaje.getText().equals("100%")) {
                        if (!downloadFrameList.get(i).lbPorcentaje.getText().equals("0%")) {
                            downloadList.get(i).cancel(true);
                            downloadFrameList.get(i).lbPorcentaje.setText("0%");
                            downloadFrameList.get(i).pbDescarga.setValue(0);
                            if (Utilities.mensajeConfirmacion("¿Desea Borrar La Descarga " + downloadFrameList.get(i).lbNdescarga.getText() + "?") == 0) {

                                try {
                                    añadirEntradaDiario("Descarga Cancelada", fileName(urlList.get(i)));
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                try {
                                    añadirEntradaDiario("Descarga Borrada", fileName(urlList.get(i)));
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                try {
                                    añadirEntradaDiario("Fichero Borrado", fileName(urlList.get(i)));
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                m.jpDescargas.remove(downloadFrameList.get(i).panel1);
                                m.jpDescargas.repaint();
                                try {
                                    downloadList.get(i).deleteFile(fileName(urlList.get(i)));
                                } catch (IOException e) {
                                    Utilities.mensajeError("Fichero no eliminado");
                                    try {
                                        añadirEntradaDiario("Borrado De Fichero Nulo", fileName(urlList.get(i)));
                                    } catch (IOException ioe) {
                                        e.printStackTrace();
                                    }
                                }
                                urlList.remove(urlList.get(i));
                            } else {
                                downloadFrameList.get(i).lbNdescarga.setText(downloadFrameList.get(i).lbNdescarga.getText() + " (Cancelada)");
                            }
                        }
                    }
                }
            }
        }
    }

    public void tratarUrl(AñadirLayout al) {

        String url = al.textField1.getText();
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < url.length(); i++) {

            if (!url.substring(i, i + 1).equals(" ")) {
                sb.append(url.substring(i, i + 1));
            }
        }

        url = String.valueOf(sb);
        urlList.add(url);
    }

    public void tratarUrl(AñadirVariosLayout avl) {

        String url = avl.textArea1.getText();
        StringBuffer sb = new StringBuffer();

        String[] x  = url.split("\n");

        for (int i = 0; i < x.length; i++) {

            for (int j = 0; j < x[i].length(); j++) {

                if (!x[i].substring(j, j + 1).equals(" ")) {
                    sb.append(x[i].substring(j, j + 1));
                }
            };

            urlList.add(String.valueOf(sb));
            sb.delete(0, sb.length());
        }
    }

    public void tratarUrl(String url) {

        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < url.length(); i++) {

            if (!url.substring(i, i + 1).equals(" ") || !url.substring(i, i + 1).equals("\n")) {
                sb.append(url.substring(i, i + 1));
            }
        }

        url = String.valueOf(sb);

        if (!url.equals("")) urlList.add(url);
    }

    public String fileName(String fileURL) throws IOException, UnknownHostException {

        URL url = new URL(fileURL);
        HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
        int responseCode = httpConn.getResponseCode();
        String disposition;
        String fileName = "";

        // always check HTTP response code first
        if (responseCode == HttpURLConnection.HTTP_OK) {
            disposition = httpConn.getHeaderField("Content-Disposition");

            if (disposition != null) {
                // extracts file name from header field
                int index = disposition.indexOf("filename=");
                if (index > 0) {
                    fileName = disposition.substring(index + 10,
                            disposition.length() - 1);
                }
            } else {
                // extracts file name from URL
                fileName = fileURL.substring(fileURL.lastIndexOf("/") + 1,
                        fileURL.length());
            }
        }

        httpConn.disconnect();
        return fileName;
    }

    public Float contentLenght(String fileURL) throws IOException {

        URL url = new URL(fileURL);
        HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
        Float contentLenght = Float.valueOf(httpConn.getContentLength());
        httpConn.disconnect();

        return contentLenght;
    }

    public void descargar() {

        for (int i = downloadFrameList.size(); i < urlList.size(); i++) {

            try {
                DownloadFrame df = new DownloadFrame();
                String filename = fileName(urlList.get(i));
                df.lbNdescarga.setText(filename);
                HTTP descarga = new HTTP(urlList.get(i), Values.descargaPATH);
                downloadList.add(descarga);
                downloadInProcess.add(descarga);
                downloadInProcessName.add(filename);
                m.jpDescargas.add(df.panel1);
                df.btParar.addActionListener(this);
                downloadFrameList.add(df);

                Float x = contentLenght(urlList.get(i));

                descarga.addPropertyChangeListener((event) -> {

                    if (event.getPropertyName().equals("progress")) {
                        df.pbDescarga.setValue((Integer) event.getNewValue());
                        df.lbPorcentaje.setText(String.valueOf((Integer) event.getNewValue()) + "%");
                        df.lbTamano.setText(String.valueOf(Math.round((x / 1000000F * (Integer) event.getNewValue() / 100F)*100F)/100F) + "/" + String.valueOf(Math.round((x / 1000000F)*100F)/100F) + " MB");
                    }
                });
                descarga.execute();
                try {
                    añadirEntradaDiario("Descarga Iniciada", filename);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                if (e instanceof MalformedURLException) {
                    try {
                        añadirEntradaDiario("URL no correcta", urlList.get(i));
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    JOptionPane.showMessageDialog(null, "La URL no es correcta", "Descargar Fichero", JOptionPane.ERROR_MESSAGE);
                } else if (e instanceof FileNotFoundException) {
                    try {
                        añadirEntradaDiario("No se ha podido leer el fichero de origen", urlList.get(i));
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    JOptionPane.showMessageDialog(null, "No se ha podido leer el fichero origen", "Descargar Fichero", JOptionPane.ERROR_MESSAGE);
                } else if (e instanceof IOException) {
                    try {
                        añadirEntradaDiario("No se ha podido leer el fichero de origen", urlList.get(i));
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    JOptionPane.showMessageDialog(null, "No se ha podido leer el fichero origen", "Descargar Fichero", JOptionPane.ERROR_MESSAGE);
                } else e.printStackTrace();
            }
        }
    }

    public void reiniciar() {

        for (int i = 0; i < downloadFrameList.size(); i++) {

            if (downloadFrameList.get(i).cbSeleccion.isSelected() && downloadFrameList.get(i).panel1.isShowing()) {

                try {
                    String filename = fileName(urlList.get(i));

                    if (!downloadList.get(i).isCancelled()) downloadList.get(i).cancel(true);
                    añadirEntradaDiario("Descarga Cancelada", filename);

                    downloadList.get(i).deleteFile(filename);

                    HTTP descarga = new HTTP(urlList.get(i), Values.descargaPATH);
                    downloadList.set(i, descarga);
                    downloadInProcess.add(descarga);
                    downloadInProcessName.add(filename);

                    int finalI = i;
                    Float x = contentLenght(urlList.get(i));
                    descarga.addPropertyChangeListener((event) -> {
                        if (event.getPropertyName().equals("progress")) {
                            downloadFrameList.get(finalI).pbDescarga.setValue((Integer) event.getNewValue());
                            downloadFrameList.get(finalI).lbPorcentaje.setText(String.valueOf((Integer) event.getNewValue()) + "%");
                            downloadFrameList.get(finalI).lbTamano.setText(String.valueOf(Math.round((x / 1000000F * (Integer) event.getNewValue() / 100F)*100F)/100F) + "/" + String.valueOf(Math.round((x / 1000000F)*100F)/100F) + " MB");
                        }
                    });
                    descarga.execute();
                    añadirEntradaDiario("Descarga Reiniciada", filename);
                } catch (Exception e) {
                    if (e instanceof MalformedURLException) {
                        try {
                            añadirEntradaDiario("URL no correcta", urlList.get(i));
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        JOptionPane.showMessageDialog(null, "La URL no es correcta", "Descargar Fichero", JOptionPane.ERROR_MESSAGE);
                    } else if (e instanceof FileNotFoundException) {
                        try {
                            añadirEntradaDiario("No se ha podido leer el fichero de origen", fileName(urlList.get(i)));
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        JOptionPane.showMessageDialog(null, "No se ha podido leer el fichero origen", "Descargar Fichero", JOptionPane.ERROR_MESSAGE);
                    } else if (e instanceof IOException) {
                        try {
                            añadirEntradaDiario("No se ha podido leer el fichero de origen", fileName(urlList.get(i)));
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        JOptionPane.showMessageDialog(null, "No se ha podido leer el fichero origen", "Descargar Fichero", JOptionPane.ERROR_MESSAGE);
                    } else e.printStackTrace();
                }
            }
        }
    }

    public void seleccionTodos(Boolean x) {

        for (int i = 0; i < downloadFrameList.size(); i++) {
          downloadFrameList.get(i).cbSeleccion.setSelected(x);
        }
    }

    public void añadir() {

        if(m.cbAñadir.getSelectedItem() == "Una URL") {

            al = new AñadirLayout();

            m.jpAñadir.add(al.panel1);
            m.jpAñadir.revalidate();
            al.aceptarButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    tratarUrl(al);
                    descargar();

                    m.jpAñadir.removeAll();
                    m.jpAñadir.revalidate();
                }
            });
            al.cancelarButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    m.jpAñadir.removeAll();
                    m.jpAñadir.revalidate();
                }
            });
        } else {

            if (m.cbAñadir.getSelectedItem() == "Varias URL") {

                avl = new AñadirVariosLayout();

                m.jpAñadir.add(avl.panel1);
                m.jpAñadir.revalidate();
                avl.aceptarButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        tratarUrl(avl);
                        descargar();
                        m.jpAñadir.removeAll();
                        m.jpAñadir.revalidate();
                    }
                });
                avl.cancelarButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        m.jpAñadir.removeAll();
                        m.jpAñadir.revalidate();
                    }
                });
            } else {

                if (m.cbAñadir.getSelectedItem() == "Url Documento") {

                    JFileChooser jfc = new JFileChooser();
                    FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
                    jfc.setFileFilter(filter);
                    jfc.setCurrentDirectory(new File(System.getProperty("user.home")));
                    jfc.setDialogTitle("Documento Url");
                    int val = jfc.showOpenDialog(null);

                    if (val == JFileChooser.APPROVE_OPTION) {
                        File selectedFile = jfc.getSelectedFile();
                        tratarTxtFile(selectedFile.getAbsolutePath());
                        descargar();
                    }
                }
            }
        }
    }

    public void tratarTxtFile(String file) {

        File fichero = null;
        FileReader lector = null;
        BufferedReader buffer = null;


        try {
            buffer = new BufferedReader( new FileReader( new File(file)));
            String line = null;

            while ((line = buffer.readLine()) != null) {

                if(line != null || line.equals("") || line.equals("\n")) tratarUrl(line);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

            if (buffer != null) {

                try {
                    buffer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void cancelar(Object s) {

        if (s == al.cancelarButton) {

            m.jpAñadir.removeAll();
            m.jpAñadir.revalidate();
        } else {

            if (s == avl.cancelarButton) {

                m.jpAñadir.removeAll();
                m.jpAñadir.revalidate();
            }
        }
    }

    public void eliminar() {

        if (m.cbEliminar.getSelectedItem() == "Solo Descarga") {

            for (int i = 0; i < downloadFrameList.size(); i++) {
                if (downloadFrameList.get(i).cbSeleccion.isSelected() && downloadFrameList.get(i).panel1.isShowing()) {
                    if (!downloadList.get(i).isCancelled()) downloadList.get(i).cancel(true);
                    try {
                        añadirEntradaDiario("Descarga Cancelada", fileName(urlList.get(i)));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    m.jpDescargas.remove(downloadFrameList.get(i).panel1);
                    m.jpDescargas.repaint();
                    try {
                        añadirEntradaDiario("Descarga Borrada", fileName(urlList.get(i)));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            if (m.jpDescargas.getComponentCount() == 0) {
                urlList.clear();
                downloadList.clear();
                downloadFrameList.clear();
                downloadInProcess.clear();
            }

        } else {

            if (m.cbEliminar.getSelectedItem() == "Datos Descargados y Descarga") {
                for (int i = 0; i < downloadFrameList.size(); i++) {
                    if (downloadFrameList.get(i).cbSeleccion.isSelected() && downloadFrameList.get(i).panel1.isShowing()) {
                        if (!downloadList.get(i).isCancelled()) downloadList.get(i).cancel(true);
                        try {
                            añadirEntradaDiario("Descarga Cancelada", fileName(urlList.get(i)));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        m.jpDescargas.remove(downloadFrameList.get(i).panel1);
                        m.jpDescargas.repaint();
                        try {
                            añadirEntradaDiario("Descarga Borrada", fileName(urlList.get(i)));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        try {
                            downloadList.get(i).deleteFile(fileName(urlList.get(i)));
                            try {
                                añadirEntradaDiario("Fichero Borrado", fileName(urlList.get(i)));
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } catch (IOException e) {
                            Utilities.mensajeError("Fichero no eliminado");
                        }
                    }
                }

                if (m.jpDescargas.getComponentCount() == 0) {
                    urlList.clear();
                    downloadList.clear();
                    downloadFrameList.clear();
                    downloadInProcess.clear();
                }
            }
        }
    }

    public void cambiarRuta() {

        JFileChooser jfc = new JFileChooser();

        jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        jfc.setCurrentDirectory(new File(System.getProperty("user.home" )));
        jfc.setDialogTitle("Cambiar Guardado" );
        int val = jfc.showSaveDialog(null);

        if (val == JFileChooser.APPROVE_OPTION) {
            File selectedFile = jfc.getSelectedFile();
            Values.descargaPATH = selectedFile.getAbsolutePath();
            m.lbRuta.setText(Values.descargaPATH);
            try {
                añadirEntradaDiario("Ruta de descarga cambiada" , Values.descargaPATH);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Properties configuracion = new Properties();
            configuracion.setProperty("path" , Values.descargaPATH);
            try {
                configuracion.store(new FileOutputStream("Descarga.props"), "Fichero Ruta Descarga");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException ioe) {

            }
        }
    }

    public void añadirEntradaDiario(String opcion, String name) throws IOException {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");
        String entrada = "[" + sdf.format(new Date()) + "]" + " | Evento = " + opcion + " | Argumento = " + name;
        diaryList.add(entrada);

        guardarDiario();
    }

    public void guardarDiario() {

        FileWriter fichero = null;
        PrintWriter escritor = null;
        d.pause(true);
        try
        {
            fichero = new FileWriter(Values.diaryPATH);
            escritor = new PrintWriter(fichero);
            for (int i = 0; i < diaryList.size(); i++) {
                escritor.println(diaryList.get(i) + "\n");
            }
        }
        catch (IOException  ioe) {
            ioe.printStackTrace();
        }
        finally {

            if (fichero != null) {
                try {
                    fichero.close();
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
            }
        }
    }

    public void diario() {

        if (diaryFrame.panel1.isVisible()) {

            diaryFrame.panel1.setVisible(false);
        } else {

            if (!diaryFrame.panel1.isVisible()) {

                diaryFrame.panel1.setVisible(true);
            }
        }
    }

    public ArrayList<String> cargarDiario() {

        ArrayList<String> diarioList = new ArrayList<>();
        File fichero = null;
        FileReader lector = null;
        BufferedReader buffer = null;


        try {
            buffer = new BufferedReader( new FileReader( new File(Values.diaryPATH)));
            String line = null;

            while ((line = buffer.readLine()) != null) {

                if (!line.equals("\n"))diarioList.add(line);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

            if (buffer != null) {

                try {
                    buffer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


        return diarioList;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        Object source = e.getSource();

        if (source.getClass() == JButton.class) {

            String actionCommand = ((JButton) source).getActionCommand();

            switch (actionCommand) {

                case "Añadir":
                    añadir();
                    break;
                case "Eliminar":
                    eliminar();
                    break;
                case "Seleccionar Todos":
                    seleccionTodos(true);
                    m.btSeleccion.setText("Deshacer");
                    break;
                case "Deshacer":
                    seleccionTodos(false);
                    m.btSeleccion.setText("Seleccionar Todos");
                    break;
                case "Parar":
                    parar(source);
                    break;
                case "Reiniciar":
                    reiniciar();
                    break;
                case "Cambiar Guardado":
                    cambiarRuta();
                    break;
                case "Diario":
                    diario();
                    break;

            }

        } else {

            if (source.getClass() == JComboBox.class) {

            }
        }
    }

    public ArrayList<DownloadFrame> getDownloadFrameList() {
        return downloadFrameList;
    }

    public List<HTTP> getDownloadList() {
        return downloadList;
    }

    public List<String> getUrlList() {
        return urlList;
    }

    public List<String> getDiaryList() {
        return diaryList;
    }

    public MainFrame getM() {
        return m;
    }

    public DiaryFrame getDiaryFrame() {
        return diaryFrame;
    }

    public List<HTTP> getDownloadInProcess() {
        return downloadInProcess;
    }

    public List<String> getDownloadInProcessName() {
        return downloadInProcessName;
    }

    public DefaultListModel<String> getDlm() {
        return dlm;
    }
}
