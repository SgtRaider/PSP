package org.raider.proyectopsp.view;

import javax.swing.*;
import java.awt.*;

/**
 * Created by raider on 20/11/15.
 */
public class SplashScreen {

    private JPanel panel1;
    private JFrame jf;

    public SplashScreen() {
    }

    public void mostrar() {

        jf = new JFrame();
        jf.getContentPane().add(panel1);
        jf.setSize(500, 500);
        jf.setUndecorated(true);
        jf.setLocationRelativeTo(null);
        jf.pack();
        jf.setVisible(true);
    }

    public void ocultar() {

        jf.setVisible(false);
    }
}
