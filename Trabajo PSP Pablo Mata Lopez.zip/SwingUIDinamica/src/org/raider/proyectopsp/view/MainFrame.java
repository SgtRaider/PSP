package org.raider.proyectopsp.view;

import org.raider.proyectopsp.controller.ControllerMainFrame;

import javax.swing.*;

/**
 * Created by raider on 15/11/15.
 */
public class MainFrame {

    public JPanel panel1;
    public JButton btAñadir;
    public JButton btEliminar;
    public JButton btParar;
    public JButton btReiniciar;
    public JComboBox cbEliminar;
    public JComboBox cbAñadir;
    public JButton btSeleccion;
    public JPanel jpAñadir;
    public JPanel jpDescargas;
    public JPanel jpScroll;
    public JButton btCambiarRuta;
    public JLabel lbRuta;
    public JPanel jpDiario;
    public JButton btDiario;

    private ControllerMainFrame cmf;

    MainFrame() {

        Thread hiloSplash = new Thread(new Runnable() {
            @Override
            public void run() {
                SplashScreen ss = new SplashScreen();
                ss.mostrar();
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                ss.ocultar();
            }

        });
        hiloSplash.start();

        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.pack();
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        jpDescargas.setLayout(new BoxLayout(jpDescargas, BoxLayout.Y_AXIS));
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        frame.setVisible(true);

        cmf = new ControllerMainFrame(this);
    }


}
