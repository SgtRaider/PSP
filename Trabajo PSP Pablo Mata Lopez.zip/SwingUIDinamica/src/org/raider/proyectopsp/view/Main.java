package org.raider.proyectopsp.view;

import org.raider.proyectopsp.view.MainFrame;

/**
 * Created by raider on 15/11/15.
 */
public class Main {

    public static void main(String args[]) {

        MainFrame m = new MainFrame();
    }
}
