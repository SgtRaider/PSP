package org.raider.proyectopsp.view;

import javax.swing.*;

/**
 * Created by raider on 27/11/15.
 */
public class DiaryFrame {
    public JList jlDiario;
    public JPanel panel1;
}
