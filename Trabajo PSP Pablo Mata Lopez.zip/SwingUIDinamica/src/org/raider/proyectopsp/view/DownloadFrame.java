package org.raider.proyectopsp.view;

import javax.swing.*;

/**
 * Created by raider on 15/11/15.
 */
public class DownloadFrame {
    public JProgressBar pbDescarga;
    public JPanel panel1;
    public JLabel lbPorcentaje;
    public JButton btParar;
    public JCheckBox cbSeleccion;
    public JLabel lbNdescarga;
    public JLabel lbTamano;
}
