package org.raider.proyectopsp.view;

import javax.swing.*;

/**
 * Created by raider on 15/11/15.
 */
public class AñadirLayout {
    public JPanel panel1;
    public JTextField textField1;
    public JButton aceptarButton;
    public JButton cancelarButton;

}
