package org.raider.proyectopsp.util;

import java.io.File;

/**
 * Created by raider on 22/11/15.
 */
public class Values {
    public static String descargaPATH = System.getProperty("user.home") + File.separator + "Descargas";
    public static String diaryPATH = System.getProperty("user.home") + File.separator + "Documentos" + File.separator + "diario.txt";
}
